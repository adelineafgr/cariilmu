const mysql = require('mysql');

//Konfigurasi MySQL
const koneksi =
mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cariilmu',
    multipleStatements: true
});

//Log error koneksi
koneksi.connect((err) => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

module.exports = koneksi;